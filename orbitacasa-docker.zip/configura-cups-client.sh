#!/bin/sh

mkdir -p /etc/cups

if [ -n "$OC_CUPS_SERVER" ]; then
    TARGET="$OC_CUPS_SERVER"
elif python3 -c "
import socket, sys
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(2)
try:
    s.connect(('host.docker.internal', 631))
    sys.exit(0)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
    TARGET="host.docker.internal"
else
    TARGET="cups"
fi

echo "ServerName $TARGET" > /etc/cups/client.conf
exit 0

