#!/bin/sh
# Avviato automaticamente dal desktop virtuale del container.
# Lancia l'app Python dalla cartella /app, con i dati persistenti su /app/db (volume ./db).

cd /app || exit 1

exec python3 /app/OrbitaCasa.pyw
