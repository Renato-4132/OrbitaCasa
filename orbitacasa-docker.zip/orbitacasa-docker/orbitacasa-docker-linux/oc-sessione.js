// Riquadro mostrato quando la connessione VNC si chiude o viene rifiutata
window.ocSessione = function () {
    if (document.getElementById("oc-sessione")) { return; }
    var d = document.createElement("div");
    d.id = "oc-sessione";
    d.style.cssText = "position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999;"
        + "display:flex;align-items:center;justify-content:center;"
        + "background:rgba(15,20,30,0.88);font-family:Arial,Helvetica,sans-serif;";
    d.innerHTML =
        '<div style="max-width:420px;margin:16px;padding:28px 32px;border-radius:12px;'
        + 'background:#ffffff;color:#1c2430;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.4);">'
        + '<h2 style="margin:0 0 12px 0;font-size:22px;">Sessione chiusa</h2>'
        + '<p style="margin:0 0 20px 0;font-size:15px;line-height:1.5;">'
        + 'La connessione &egrave; terminata. Pu&ograve; essere per inattivit&agrave; '
        + 'oppure perch&eacute; un altro schermo &egrave; gi&agrave; collegato.</p>'
        + '<button type="button" id="oc-ricarica" style="padding:10px 22px;border:0;'
        + 'border-radius:8px;background:#2a6df4;color:#ffffff;font-size:15px;cursor:pointer;">'
        + 'Ricarica la pagina</button></div>';
    document.body.appendChild(d);
    document.getElementById("oc-ricarica").addEventListener("click", function () {
        location.reload();
    });
};
