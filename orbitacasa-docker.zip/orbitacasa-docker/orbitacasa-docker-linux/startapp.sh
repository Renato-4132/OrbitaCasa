#!/bin/sh
# Avviato automaticamente dal desktop virtuale del container.
# Lancia l'app Python dalla cartella /app, con i dati persistenti su /app/db (volume ./app).

cd /app || exit 1

# Ramo e nome file del repository:
BRANCH=main
FILE=OrbitaCasa.pyw
URL="https://raw.githubusercontent.com/Renato-4132/OrbitaCasa/$BRANCH/$FILE"

if [ ! -f /app/OrbitaCasa.pyw ]; then
  python3 -c "import urllib.request as u; u.urlretrieve('$URL', '/app/OrbitaCasa.pyw.tmp')" \
    && mv /app/OrbitaCasa.pyw.tmp /app/OrbitaCasa.pyw
fi

tint2 &

# Disconnessione per inattivita': se OC_IDLE_MINUTI > 0, dopo quei minuti senza
# mouse/tastiera riavvia webauth e nginx, quindi il browser torna al login
if [ "${OC_IDLE_MINUTI:-0}" -gt 0 ] 2>/dev/null; then
  (
    soglia=$((OC_IDLE_MINUTI * 60000))
    ultimo=$(( $(date +%s) * 1000 ))
    while sleep 10; do
      ora=$(( $(date +%s) * 1000 ))
      idle=$(DISPLAY=:0 xprintidle 2>/dev/null) || continue
      da_kill=$((ora - ultimo))
      [ "$da_kill" -lt "$idle" ] && idle=$da_kill
      if [ "$idle" -ge "$soglia" ]; then
        pkill -f '^webauth'
        pkill -f 'nginx: worker process'
        ultimo=$ora
      fi
    done
  ) &
fi

# Chiusura dell'app per inattivita': se OC_CHIUDI_MINUTI > 0, dopo quei minuti
# senza mouse/tastiera chiude OrbitaCasa. Il container si riavvia da solo
# (restart: unless-stopped) e l'app riparte pulita, in attesa del prossimo accesso
if [ "${OC_CHIUDI_MINUTI:-0}" -gt 0 ] 2>/dev/null; then
  (
    soglia_chiudi=$((OC_CHIUDI_MINUTI * 60000))
    while sleep 10; do
      idle=$(DISPLAY=:0 xprintidle 2>/dev/null) || continue
      # Chi usa il web server remoto (porte 8080/8081) non tocca mouse e tastiera
      # del desktop: finche' c'e' un collegamento aperto l'app non viene chiusa
      if netstat -tn 2>/dev/null | awk '$6=="ESTABLISHED" && $4 ~ /:(8080|8081)$/ {f=1} END{exit !f}'; then
        continue
      fi
      if [ "$idle" -ge "$soglia_chiudi" ]; then
        pkill -f '^python3 /app/OrbitaCasa.pyw'
        sleep 30
      fi
    done
  ) &
fi

exec python3 /app/OrbitaCasa.pyw
