#!/bin/sh

cd /app || exit 1

# Ramo e nome file del repository: se non sono questi, cambia solo queste due righe
BRANCH=main
FILE=OrbitaCasa.pyw
URL="https://raw.githubusercontent.com/Renato-4132/OrbitaCasa/$BRANCH/$FILE"

if [ ! -f /app/OrbitaCasa.pyw ]; then
  python3 -c "import urllib.request as u; u.urlretrieve('$URL', '/app/OrbitaCasa.pyw.tmp')" \
    && mv /app/OrbitaCasa.pyw.tmp /app/OrbitaCasa.pyw
fi

tint2 &

exec python3 /app/OrbitaCasa.pyw
