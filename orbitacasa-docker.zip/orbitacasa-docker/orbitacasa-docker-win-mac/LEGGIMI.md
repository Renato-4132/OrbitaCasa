# OrbitaCasa in Docker (Windows / Mac) — Guida rapida

## Cosa fa questo setup

Impacchetta OrbitaCasa (app Python/Tkinter) dentro un container Linux con un
"desktop virtuale" incluso. Il container espone una pagina web (porta 5800):
apri quella pagina nel browser e vedi la finestra dell'app esattamente come
si vedrebbe su schermo — senza dover installare nulla sul PC client.

Non è una riscrittura web dell'app: è la stessa app, "trasmessa" nel browser.

## Passaggi

1. Installa **Docker Desktop** (https://www.docker.com/products/docker-desktop/).
   Su Windows usa il backend WSL2 (proposto di default dall'installer) e
   riavvia il PC se richiesto. Lascia Docker Desktop in esecuzione.

2. Crea una cartella sul PC e mettici dentro questi 5 file (Dockerfile,
   startapp.sh, configura-cups-client.sh, docker-compose.yml, LEGGIMI.md)
   insieme a `OrbitaCasa.pyw` (scaricato singolarmente, es. dalla pagina
   GitHub del file — non serve clonare/scaricare tutto il repo).

   **Non serve nemmeno `moduli/` né `resources/`**: se ne occupa l'app da
   sola al primo avvio (scarica `moduli/` da GitHub, crea `resources/`
   dentro `db/`). Basta il `.pyw`.

3. Apri un terminale (PowerShell) dentro quella cartella e avvia tutto con
   un comando:
   ```
   docker compose up -d --build
   ```
   La prima volta la build richiede qualche minuto.

4. Apri il browser su:
   ```
   https://localhost:5800
   ```
   (da un altro PC della rete: `https://IP-DEL-PC:5800`). HTTPS con
   certificato autofirmato: il browser avviserà "non sicuro", va accettato
   una volta. Vedrai l'interfaccia di OrbitaCasa dentro la pagina.

## Dati persistenti

Tutto ciò che l'app salva va in `./db` sul server (montato su `/app/db` nel
container), così sopravvive a rebuild e aggiornamenti — comprese
`resources/` (creata lì dall'app stessa) e il database.

`moduli/` invece vive **dentro** il container, in `/app/moduli`, non su un
volume: ad ogni build/ricreazione del container viene ri-scaricata da
GitHub da zero. Comportamento voluto: un rebuild riparte sempre pulito con
l'ultima versione, l'updater interno dell'app gestisce eventuali
aggiornamenti nel frattempo. Se buildi/riavvii molto spesso in poco tempo
puoi incappare nel rate limit dell'API GitHub anonima (`403 rate limit
exceeded`): basta aspettare un'ora, oppure passare un token GitHub all'app
se supportato (verificare in `aggiornamenti_app.py`).

**Attenzione — non eseguire due istanze in parallelo:** se lanci
OrbitaCasa anche fuori dal container (avviando il `.pyw` direttamente
sull'host), evita di farlo mentre il container è in esecuzione. Le due
istanze non comunicano tra loro: se puntano allo stesso database
(`./db`), ognuna lo legge/scrive per conto suo, senza sapere cosa fa
l'altra. Usarle contemporaneamente può causare disallineamento dei
dati o, nel peggiore dei casi, sovrascritture che si perdono a
vicenda. Usa un'istanza alla volta.

### Permessi delle cartelle montate

`./db`, `./config` ed `./esporta` sul server vengono creati con l'utente che
lancia `docker compose`, ma il container gira internamente con un utente a
UID/GID fissi — senza correzione, la prima scrittura dell'app lì dentro
fallirebbe con `Permission denied`. Il Dockerfile include già uno script di
inizializzazione (`/etc/cont-init.d/90-fix-permissions.sh`) che sistema i
permessi di `db/`, `moduli/`, `esporta/` e `config/` automaticamente **ad
ogni avvio del container**, prima che l'app parta — non serve mai fare
`chown` a mano, anche cancellando/ricreando quelle cartelle sull'host.

## Salvare file fuori dal container (PDF, export, ecc.)

L'app gira dentro al container: qualunque "Salva con nome" scrive di
default nel filesystem del container, non sul PC da cui guardi il browser.
Due modi per portare un file fuori:

- **Al volo, un file per volta:** nella finestra noVNC, muovendo il mouse
  sul bordo compare la control bar con un file manager integrato — da lì
  puoi scaricare un file dal container al tuo PC (o caricarne uno dal PC
  nel container).
- **In automatico, sempre:** nel dialogo "Salva con nome" dell'app, scegli
  come destinazione la cartella `/app/esporta`. È montata come volume
  (`./esporta` sull'host), quindi tutto quello che ci salvi dentro compare
  subito sul server, esattamente come già succede con `./db` — nessun
  passaggio dal file manager.

## Configurazione consigliata (`docker-compose.yml`)

```yaml
services:
  orbitacasa:
    build: .
    container_name: orbitacasa
    environment:
      - SECURE_CONNECTION=1     # HTTPS (autofirmato) sulla porta 5800
      - DISPLAY_WIDTH=1366      # risoluzione virtuale del desktop
      - DISPLAY_HEIGHT=660
      # Di norma lascia questa riga commentata: il rilevamento automatico
      # sceglie da solo il CUPS dell'host se lo trova, altrimenti il
      # container "cups" qui sotto. Scommentala SOLO per forzare un server
      # specifico (occhio al nome: NON chiamarla "CUPS_SERVER", altrimenti
      # le librerie CUPS la userebbero al posto della configurazione,
      # anche se vuota, causando l'errore "Scheduler is not running").
      # - OC_CUPS_SERVER=indirizzo-server-cups
    extra_hosts:
      - "host.docker.internal:host-gateway"
    ports:
      - "5800:5800"
    volumes:
      - ./db:/app/db
      - ./config:/config
      - ./moduli:/app/moduli
      - ./esporta:/app/esporta
    restart: unless-stopped
    shm_size: "1gb"
    depends_on:
      - cups

  cups:
    image: olbat/cupsd
    container_name: cups-server
    # Porta 6631 sull'host per evitare conflitti se l'host ha gia' CUPS
    # sulla 631 (come sul Raspberry Pi). La comunicazione interna tra i
    # due container avviene comunque sulla porta 631, indipendentemente
    # da questo mapping.
    ports:
      - "6631:631"
    volumes:
      - ./cups-config:/etc/cups
      - /var/run/dbus:/var/run/dbus
    restart: unless-stopped
```

**Risoluzione:** `DISPLAY_WIDTH`/`DISPLAY_HEIGHT` impostano la risoluzione
di partenza del desktop virtuale (1366x660 sopra, per l'uso testato). Il
resize/adattamento alla finestra del browser funziona di default, senza
bisogno di toccare le impostazioni del client noVNC.

## Comandi utili

Da eseguire in PowerShell (o nel terminale) dentro la cartella del progetto.

**Avvio/riavvio normale** (dopo modifiche a `docker-compose.yml`, senza
toccare Dockerfile/codice):
```
docker compose up -d
```

**Rebuild completo** (dopo modifiche a Dockerfile/startapp.sh/OrbitaCasa.pyw):
```
docker compose up -d --build
```

**Rebuild forzato ignorando la cache** (se una build sembra non aver
recepito una modifica):
```
docker builder prune -a -f
docker compose up -d --build
```

**Ricreare il container da zero:**
```
docker compose up -d --build --force-recreate
```

**Vedere i log in diretta:**
```
docker logs -f orbitacasa
```

**Fermare tutto:**
```
docker compose down
```
