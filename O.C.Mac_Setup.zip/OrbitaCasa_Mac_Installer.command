#!/bin/bash
# ============================================================================
#  OrbitaCasa — Installer Rapido per Mac
# ============================================================================

set -e

# URL diretto del file raw di OrbitaCasa.pyw su GitHub
PYW_URL="https://raw.githubusercontent.com/Renato-4132/OrbitaCasa/main/OrbitaCasa.pyw"

info()  { printf "\033[1;34m➤ %s\033[0m\n" "$1"; }
ok()    { printf "\033[1;32m✓ %s\033[0m\n" "$1"; }
warn()  { printf "\033[1;33m⚠ %s\033[0m\n" "$1"; }
err()   { printf "\033[1;31m✗ %s\033[0m\n" "$1"; }

echo ""
echo "=============================================="
echo "   OrbitaCasa — Installazione Rapida Mac"
echo "=============================================="
echo ""

read -r -p "Nome della cartella/profilo utente da creare sul Desktop: " PROFILE_NAME
while [ -z "$PROFILE_NAME" ]; do
    read -r -p "Il nome non può essere vuoto. Riprova: " PROFILE_NAME
done

DEST_DIR="$HOME/Desktop/$PROFILE_NAME"
mkdir -p "$DEST_DIR"
ok "Cartella creata: $DEST_DIR"

info "Scarico OrbitaCasa.pyw..."
if ! curl -fsSL "$PYW_URL" -o "$DEST_DIR/OrbitaCasa.pyw"; then
    err "Download fallito. Controlla la connessione o l'URL."
    read -n 1 -s -r -p "Premi un tasto per chiudere..."
    exit 1
fi
ok "File scaricato con successo!"

PYTHON_BIN="python3"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
    err "Python 3 non è trovato nel terminale. Assicurati di averlo installato."
    read -n 1 -s -r -p "Premi un tasto per chiudere..."
    exit 1
fi

echo ""
info "Avvio OrbitaCasa..."
cd "$DEST_DIR"

nohup "$PYTHON_BIN" "OrbitaCasa.pyw" >/dev/null 2>&1 &
disown

ok "Fatto! L'app è stata avviata."
echo ""
read -n 1 -s -r -p "Premi un tasto per uscire..."

