#!/bin/bash
# ============================================================================
#  OrbitaCasa — Installer per macOS
# ----------------------------------------------------------------------------
#  1) Controlla se Python 3.10+ è installato; se manca lo installa
#     (tramite Homebrew, installando anche Homebrew se serve)
#  2) Chiede il nome della cartella da creare (= nome profilo utente)
#  3) Scarica OrbitaCasa.pyw + la cartella moduli/ dal repository GitHub
#  4) Avvia l'app
#
#  USO: doppio click su questo file. La prima volta macOS potrebbe chiedere
#  conferma in Preferenze di Sistema > Privacy e Sicurezza, come per ogni
#  script scaricato da internet.
# ============================================================================

set -e

REPO_URL="https://github.com/Renato-4132/OrbitaCasa"
REPO_OWNER="Renato-4132"
REPO_NAME="OrbitaCasa"
PYTHON_MIN_MAJOR=3
PYTHON_MIN_MINOR=10

info()  { printf "\033[1;34m➤ %s\033[0m\n" "$1"; }
ok()    { printf "\033[1;32m✓ %s\033[0m\n" "$1"; }
warn()  { printf "\033[1;33m⚠ %s\033[0m\n" "$1"; }
err()   { printf "\033[1;31m✗ %s\033[0m\n" "$1"; }

echo ""
echo "=============================================="
echo "   OrbitaCasa — Installazione guidata per Mac"
echo "=============================================="
echo ""

# ---- 1) Controlla / installa Python ----------------------------------------
find_python() {
    for candidate in python3.13 python3.12 python3.11 python3.10 python3; do
        if command -v "$candidate" >/dev/null 2>&1; then
            local ver maj min
            ver=$("$candidate" -c 'import sys;print(f"{sys.version_info[0]}.{sys.version_info[1]}")' 2>/dev/null) || continue
            maj=${ver%%.*}
            min=${ver##*.}
            if [ "$maj" -gt "$PYTHON_MIN_MAJOR" ] || { [ "$maj" -eq "$PYTHON_MIN_MAJOR" ] && [ "$min" -ge "$PYTHON_MIN_MINOR" ]; }; then
                echo "$candidate"
                return 0
            fi
        fi
    done
    return 1
}

info "Controllo se Python ${PYTHON_MIN_MAJOR}.${PYTHON_MIN_MINOR}+ è già installato..."
PYTHON_BIN="$(find_python || true)"

if [ -z "$PYTHON_BIN" ]; then
    warn "Python non trovato (o versione troppo vecchia). Lo installo."

    if ! command -v brew >/dev/null 2>&1; then
        info "Installo Homebrew (serve per installare Python)..."
        info "Potrebbe essere richiesta la password del Mac."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        if [ -x /opt/homebrew/bin/brew ]; then
            eval "$(/opt/homebrew/bin/brew shellenv)"
        elif [ -x /usr/local/bin/brew ]; then
            eval "$(/usr/local/bin/brew shellenv)"
        fi
    fi

    info "Installo Python tramite Homebrew..."
    brew install python

    PYTHON_BIN="$(find_python || true)"
    if [ -z "$PYTHON_BIN" ]; then
        err "Python non risulta ancora disponibile. Riavvia il Terminale e rilancia lo script."
        read -n 1 -s -r -p "Premi un tasto per chiudere..."
        exit 1
    fi
fi

ok "Uso $PYTHON_BIN ($("$PYTHON_BIN" -c 'import sys;print(sys.version.split()[0])'))"

# ---- 2) Chiede il nome della cartella (= profilo) ---------------------------
echo ""
read -r -p "Nome della cartella/profilo da creare (es. il tuo nome utente): " PROFILE_NAME
while [ -z "$PROFILE_NAME" ]; do
    read -r -p "Il nome non può essere vuoto. Nome della cartella/profilo: " PROFILE_NAME
done

DEST_DIR="$HOME/$PROFILE_NAME"

if [ -d "$DEST_DIR" ] && [ -f "$DEST_DIR/OrbitaCasa.pyw" ]; then
    warn "La cartella \"$DEST_DIR\" esiste già con OrbitaCasa dentro: la riuso senza riscaricare."
else
    mkdir -p "$DEST_DIR"
    ok "Cartella profilo: $DEST_DIR"

    # ---- 3) Scarica OrbitaCasa.pyw + moduli/ da GitHub ----------------------
    info "Scarico OrbitaCasa da $REPO_URL ..."
    TMP_DIR="$(mktemp -d)"
    trap 'rm -rf "$TMP_DIR"' EXIT

    DOWNLOADED=0
    for BRANCH in main master; do
        ZIP_URL="https://codeload.github.com/${REPO_OWNER}/${REPO_NAME}/zip/refs/heads/${BRANCH}"
        if curl -fsSL "$ZIP_URL" -o "$TMP_DIR/repo.zip" 2>/dev/null; then
            DOWNLOADED=1
            break
        fi
    done

    if [ "$DOWNLOADED" -ne 1 ]; then
        err "Download fallito da $REPO_URL."
        echo "  Se il repository è privato serve autenticarsi (token GitHub);"
        echo "  se l'indirizzo è cambiato, aggiorna REPO_OWNER/REPO_NAME in cima allo script."
        read -n 1 -s -r -p "Premi un tasto per chiudere..."
        exit 1
    fi

    unzip -q "$TMP_DIR/repo.zip" -d "$TMP_DIR"
    SRC_DIR="$(find "$TMP_DIR" -maxdepth 1 -type d -name "${REPO_NAME}-*" | head -n 1)"

    if [ -z "$SRC_DIR" ] || [ ! -f "$SRC_DIR/OrbitaCasa.pyw" ]; then
        err "Nel repository scaricato non trovo OrbitaCasa.pyw."
        echo "  Controlla che il file sia nella root del repository $REPO_URL."
        read -n 1 -s -r -p "Premi un tasto per chiudere..."
        exit 1
    fi

    cp "$SRC_DIR/OrbitaCasa.pyw" "$DEST_DIR/"
    if [ -d "$SRC_DIR/moduli" ]; then
        cp -R "$SRC_DIR/moduli" "$DEST_DIR/"
    else
        warn "Cartella moduli/ non trovata nel repository: l'app potrebbe non avviarsi."
    fi

    ok "OrbitaCasa scaricato in $DEST_DIR"
fi

# ---- 4) Avvia l'app ---------------------------------------------------------
echo ""
info "Avvio OrbitaCasa..."
cd "$DEST_DIR"
"$PYTHON_BIN" "OrbitaCasa.pyw"
